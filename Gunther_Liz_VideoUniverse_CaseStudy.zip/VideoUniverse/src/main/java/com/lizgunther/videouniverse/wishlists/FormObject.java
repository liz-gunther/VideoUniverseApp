package com.lizgunther.videouniverse.wishlists;

public class FormObject {

    private long wishlistId;

    public FormObject() {
    }

    public long getWishlistId() {
        return wishlistId;
    }

    public void setWishlistId(long wishlistId) {
        this.wishlistId = wishlistId;
    }
}
