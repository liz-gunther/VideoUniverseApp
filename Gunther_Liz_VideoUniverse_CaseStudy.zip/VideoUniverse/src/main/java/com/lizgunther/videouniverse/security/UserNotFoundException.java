package com.lizgunther.videouniverse.security;

public class UserNotFoundException extends RuntimeException {
}
