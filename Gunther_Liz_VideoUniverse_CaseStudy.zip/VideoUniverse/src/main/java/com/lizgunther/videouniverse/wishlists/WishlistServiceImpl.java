package com.lizgunther.videouniverse.wishlists;

import com.lizgunther.videouniverse.movies.Movie;
import com.lizgunther.videouniverse.security.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class WishlistServiceImpl implements WishlistService {

    private WishlistRepository wishlistRepository;
    private UserService userService;

    @Autowired
    public WishlistServiceImpl(WishlistRepository wishlistRepository, UserService userService) {
        this.wishlistRepository = wishlistRepository;
        this.userService = userService;
    }

    @Override
    public void saveToWishlist(Wishlist wishlist) {
        this.wishlistRepository.save(wishlist);
    }


    @Override
    public Set<Wishlist> getWishlistsByUserId(long id) {
        return userService.getUserById(id).getWishlists();
    }

    @Override
    public Wishlist getWishlistById(long id) {
        return wishlistRepository.getById(id);
    }

    @Override
    public void saveWishlist(Wishlist wishlist) {
        this.wishlistRepository.save(wishlist);
    }

    @Override
    public void deleteWishlistById(long id) {
        this.wishlistRepository.deleteById(id);
    }

    @Override
    public Wishlist getWishlistByUserId(long id) {
        return wishlistRepository.getById(id);
    }

    @Override
    public void deleteMovieFromWishlist(long id, Movie movie) {
        Wishlist wishlist = wishlistRepository.getById(id);
        wishlist.getMovies().remove(movie);
        wishlistRepository.save(wishlist);
    }


}
