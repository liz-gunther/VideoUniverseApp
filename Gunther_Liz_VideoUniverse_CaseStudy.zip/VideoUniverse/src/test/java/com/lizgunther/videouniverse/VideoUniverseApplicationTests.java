package com.lizgunther.videouniverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoUniverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
